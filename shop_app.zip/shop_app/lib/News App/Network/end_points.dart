const LOGIN='login';
const REGISTER='register';
const HOME='home';
const GET_CATEGORIES='categories';
const FAVORITES='favorites';
const PROFILE='profile';
const UPDATE_PROFILE='update-profile';
const SEARCH='products/search';



