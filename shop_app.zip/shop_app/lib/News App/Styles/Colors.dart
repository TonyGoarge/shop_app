import 'package:flutter/material.dart';

const defaultColor=Colors.blue;