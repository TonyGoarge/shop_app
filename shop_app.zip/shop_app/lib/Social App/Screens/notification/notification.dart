import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context)
  {
    return Text(
      'Notification',
    );
  }
}
