import 'package:flutter/material.dart';

class UsersScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context)
  {
    return Text(
      'Users',
    );
  }
}
