import 'package:flutter/material.dart';
import 'package:switcher_button/switcher_button.dart';

class ChatsScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context)
  {
    return Column(
      children: [
       Row(
         children:[
           Text(
            'Dark Mode'
    ),
           Spacer(),
           SwitcherButton(onColor: Colors.pink,
           onChange:(value) {
             print('welcome');
           }),

         ],

       ) ,
      ]
    );
  }
}
