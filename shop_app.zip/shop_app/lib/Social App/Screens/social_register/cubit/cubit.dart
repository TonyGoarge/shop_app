import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shop_app/Social%20App/Screens/social_register/cubit/states.dart';
import 'package:shop_app/Social%20App/models/social_user_model.dart';




class SocialRegisterCubit extends Cubit<SocialRegisterStates>
{
  SocialRegisterCubit():super(SocialRegisterInitialState());

  static SocialRegisterCubit get(context)=>BlocProvider.of(context);

  void userRegister
      ({
    required String name,
    required String email,
    required String phone,
    required String password,


      })
  {
    emit(SocialRegisterLoadingState());
  FirebaseAuth.instance.createUserWithEmailAndPassword(
    email: email,
    password: password,)
      .then((value)
  {

    userCreate(
      name: name,
      email: email,
      phone:phone,

      uId: value.user!.uid,


    );
  }
  ).catchError((error)
  {
    emit(SocialRegisterErrorState(error.toString()));

  });
  }

  void userCreate({
    required String name,
    required String email,
    required String phone,
    required String uId,

})

  {
    SocialUserModel model=SocialUserModel(
      name:name,
      email:email,
      phone:phone,
      uId:uId,
      bio:'write your bio ...',
      image:'https://cdn-icons-png.flaticon.com/512/145/145849.png?w=740&t=st=1676415348~exp=1676415948~hmac=5d530185bd6053c8583f18a5298a75c4ae144653457ce3a9f511b615c517e6dc',
      cover:'https://img.freepik.com/free-photo/top-view-table-full-delicious-food-composition_23-2149141353.jpg?w=996&t=st=1676809428~exp=1676810028~hmac=87ebbb3cdfa6708e7572150b566f3544e2c10c13ee25566c7cb628433eaf134d',
      isEmailVerified: false,
    );

FirebaseFirestore.instance
    .collection('users')
    .doc(uId)                          //عشان هشتغل علي uId
    .set(model.toMap())
    .then((value) {
      emit(SocialCreateUserSuccessState());
}).catchError((error){
  emit(SocialCreateUserErrorState(error.toString()));

});
  }


  IconData suffix= Icons.visibility_outlined;
  bool isPassword=false;
  void ChangePasswordVisibility()
  {
    isPassword=!isPassword;
    suffix=isPassword? Icons.visibility_outlined : Icons.visibility_off_outlined;
    emit(SocialRegisterChangePasswordvisibilityState());
  }

}

